
/root/preseed/run_once/logo.sh >> /root/preseed/3.log
/root/preseed/run_once/mysql.sh >> /root/preseed/3.log

systemctl disable run_once.service >> /root/preseed/3.log

rm -rf /root/preseed
