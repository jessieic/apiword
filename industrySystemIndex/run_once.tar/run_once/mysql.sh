#!/bin/bash
mysqladmin -u root password 123456
mysql -uroot -p123456 -e "create database snort;"
if [ $? -eq 0 ];then
    echo "snort create database success"
else
    echo "snort create database failed" >&2
fi
mysql -uroot -p123456 -e "CREATE USER 'snort'@'localhost' IDENTIFIED BY '123456';"
if [ $? -eq 0 ];then
    echo "snort create user success"
else
    echo "snort create user failed" >&2
fi
mysql -uroot -p123456 -e "grant create, insert, select, delete, update on snort.* to 'snort'@'localhost';"
mysql -uroot -p123456 -e "FLUSH PRIVILEGES;"
#导入数据库文件
mysql -uroot -p123456 snort </root/preseed/run_once/snort-dafault-data.sql
if [ $? -eq 0 ];then
    echo "snort improt default data success"
else
    echo "snort improt default data failed" >&2
fi
